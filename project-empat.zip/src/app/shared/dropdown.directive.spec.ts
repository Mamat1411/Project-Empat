/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DropdownDirective } from './dropdown.directive';

describe('Directive: Dropdown', () => {
  it('should create an instance', () => {
    const directive = new DropdownDirective();
    expect(directive).toBeTruthy();
  });
});
